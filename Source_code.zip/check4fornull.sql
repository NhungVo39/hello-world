sp_setapprole 'afis_role_qa', 'afis_role_qa'

SELECT * FROM Person WHERE PersonID is NULL or PersonID = '0'

SELECT * FROM Name WHERE NameID is NULL or NameID = '0'

SELECT * FROM Registration WHERE RegistrationID is NULL or RegistrationID = '0'

SELECT * FROM RegPerson WHERE RegPersonID is NULL or RegPersonID = '0'

SELECT * FROM Veto WHERE VetoID is NULL or VetoID = '0'

SELECT * FROM VetoPerson WHERE VetoPersonID is NULL or VetoPersonID = '0'

SELECT * FROM Contact WHERE ContactID is NULL or ContactID = '0'

SELECT * FROM ContactPerson WHERE ContactPersonID is NULL or ContactPersonID = '0'

SELECT * FROM ICA WHERE ICAID is NULL or ICAID = '0'

SELECT * FROM ABC WHERE ABCID is NULL or ABCID = '0'