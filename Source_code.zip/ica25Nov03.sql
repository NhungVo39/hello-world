SELECT *
FROM ICA
WHERE ICAID is NULL or ICAID = '5006' or ICAID = '5007' or ICAID = '5010' or ICAID = '5011'

SELECT *
FROM Person
WHERE PersonID is NULL or PersonID = '200032' or PersonID = '200033' or PersonID = '200034'

SELECT *
FROM Name
WHERE NameID is NULL or PersonID = '200032' or PersonID = '200033' or PersonID = '200034'

SELECT *
FROM Address
WHERE AddressID is NULL or AddressID = '200011' or AddressID = '200012'

SELECT *
FROM ICAChild
WHERE ChildID = '200034'

