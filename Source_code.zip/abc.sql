SELECT * FROM ABC WHERE ABCID is Null or ABCID = '0' or ABCID = '19' or ABCID = '20' or ABCID = '21'
SELECT * FROM Name WHERE NameID is Null or NameID = '0' or PersonID = '31006' or PersonID = '31007'
SELECT * FROM Person WHERE PersonID is Null or PersonID = '0' or PersonID = '31006' or PersonID = '31007'
SELECT * FROM Address WHERE AddressID is Null or AddressID = '0' or AddressID = '31433' or AddressID = '31434'
SELECT * FROM ABCChild WHERE ABCChildID is Null or ABCChildID = '0' or ABCChildID = '49'

select * from nextid







