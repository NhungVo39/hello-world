sp_setapprole 'afis_role_qa', 'afis_role_qa'

SELECT * FROM Person WHERE PersonID is Null or PersonID = '0'

SELECT * FROM Name WHERE NameID is Null or NameID = '0'

SELECT * FROM Address WHERE AddressID is Null or AddressID = '0'
SELECT * FROM AddrPerson WHERE AddrPersonID is Null or AddrPersonID = '0'

SELECT * FROM Veto WHERE VetoID is Null or VetoID = '0'
SELECT * FROM VetoPerson WHERE VetoPersonID is Null or VetoPersonID = '0'

SELECT * FROM Registration WHERE RegistrationID is Null or RegistrationID = '0'
SELECT * FROM RegPerson WHERE RegPersonID is Null or RegPersonID = '0'

SELECT * FROM Contact WHERE ContactID is Null or ContactID = '0'
SELECT * FROM ContactPerson WHERE ContactPersonID is Null or ContactPersonID = '0'

