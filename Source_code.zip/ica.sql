
select * from ICA WHERE ICAID = '2'

SELECT * FROM Address WHERE AddressID = '0' or AddressID is Null or AddressID = '200114'
SELECT * FROM Person WHERE PersonID = '0' or PersonID is Null or PersonID = '29352' or PersonID = '29353'
SELECT * FROM Name WHERE NameID = '0' or NameID is Null or PersonID = '29352' or PersonID = '29353'
select * from ICAChild where ICAChildID is Null or ICAChildID = '0' or ChildID = '30995' or ChildID = '31009'

update ICA set ProgressReport2 = '2' where ProgressReport2 = 'Y'