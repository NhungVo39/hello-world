SELECT *
FROM ABC
WHERE ABCID is NULL or ABCID = '125' or ABCID = '126'

SELECT *
FROM Person
WHERE PersonID is NULL or PersonID = '200029' or PersonID = '200030' or PersonID = '200031'

SELECT *
FROM Name
WHERE NameID is NULL or PersonID = '200029' or PersonID = '200030' or PersonID = '200031'

SELECT *
FROM Address
WHERE AddressID is NULL or AddressID = '200010' or AddressID = '200009'

SELECT *
FROM ABCChild
WHERE ABCChildID is NULL or ChildID = '200031'






DELETE ABC
WHERE ABCID = '123'

DELETE Person
WHERE PersonID = '200028'

DELETE Name
WHERE PersonID = '200028'

DELETE Address
WHERE AddressID = '200008'

DELETE ABCChild
WHERE ABCChildID = '100093'