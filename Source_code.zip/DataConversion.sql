select * from ABC
select * from ABCChild
select count(*) from Address
select count(*) from Person
select count(*) from Name
select count(*) from ABC
select * from ICA


Select * from Name order by NameID desc



select * from ICA where icaid = '75'
select * from Name where PersonID = '31594'
select * from Person where PersonID = '31594'

select * from icaChild where ChildID = '30657'

delete Name where NameID = '52083'
delete Person where PersonID = '30657'
delete ICAChild where icachildid = '39'