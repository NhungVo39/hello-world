sp_setapprole 'afis_role_qa', 'afis_role_QA'

SELECT *
FROM Person
WHERE PersonID is NULL or PersonID = '200053'

SELECT *
FROM Name
WHERE NameID is NULL or PersonID = '200053'

SELECT *
FROM Address
WHERE AddressID is NULL or AddressID = '200033' or AddressID = '200034'

SELECT *
FROM AddrPerson
WHERE AddrPersonID is NULL or AddressID = '200033' or AddressID = '200034'


SELECT *
FROM Veto
WHERE VetoID is NULL or VetoID = '100115'

SELECT *
FROM VetoPerson
WHERE VetoPersonID is NULL or VetoID = '100115'

SELECT *
FROM Registration
WHERE RegistrationID is NULL or RegistrationID = '100017'

SELECT *
FROM RegPerson
WHERE RegPersonID is NULL or RegistrationID = '100017'

SELECT *
FROM Contact
WHERE ContactID is NULL or ContactID = '100010'

SELECT *
FROM ContactPerson
WHERE ContactPersonID is NULL or ContactID = '100010'

delete Registration
where RegistrationID = ''

delete RegPerson
where Registrationid = '100116'

SELECT *
FROM Comment
WHERE CommentID = '100021' or CommentID = '100022'

SELECT *
FROM Address
WHERE AddressID is NULL or AddressID = '200022' or AddressID = '200021'

SELECT *
FROM AddrPerson
WHERE AddrPersonID is NULL or PersonID = '200038'

